import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sayatechtz – Digital Products Marketplace Tanzania",
  description: "Sayatechtz - Premium digital products marketplace in Tanzania. Pakua free & paid digital products. UI Kits, Templates, E-Books, Courses, Graphics & more. Secure payment via WhatsApp.",
  keywords: ["digital products", "download", "UI kits", "templates", "e-books", "courses", "free downloads", "premium products", "Tanzania", "Sayatechtz"],
  authors: [{ name: "Sayatechtz Team" }],
  icons: {
    icon: "/logo.png",
  },
  openGraph: {
    title: "Sayatechtz – Digital Products Marketplace",
    description: "Premium digital products marketplace in Tanzania with secure downloads",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sayatechtz – Digital Products",
    description: "Premium digital products marketplace in Tanzania with secure downloads",
  },
  viewport: "width=device-width, initial-scale=1",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="Premium digital products marketplace. Download free and paid UI kits, templates, e-books, courses, and more. Secure checkout with PayPal, Stripe, or WhatsApp payment." />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
