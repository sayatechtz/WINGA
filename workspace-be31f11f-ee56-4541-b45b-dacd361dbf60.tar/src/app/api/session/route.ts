import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    // Import auth options and get session
    const { authOptions } = await import("@/lib/auth");
    const { getServerSession } = await import("next-auth");
    
    const session = await getServerSession(authOptions);
    
    if (session?.user) {
      // Check if user exists in our database
      const { db } = await import("@/lib/db");
      const user = await db.user.findUnique({
        where: { email: session.user.email! }
      });
      
      if (user) {
        return NextResponse.json({
          session: {
            user: {
              id: user.id,
              email: user.email,
              name: user.name,
              image: user.image,
              role: user.role,
            }
          }
        });
      }
    }
    
    return NextResponse.json({ session: null });
  } catch (error) {
    console.error("Session error:", error);
    return NextResponse.json({ session: null });
  }
}
