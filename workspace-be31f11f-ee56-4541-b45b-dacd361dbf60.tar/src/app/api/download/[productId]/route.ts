import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ productId: string }> }
) {
  try {
    const { productId } = await params;
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: "You must be logged in to download" },
        { status: 401 }
      );
    }

    const product = await db.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // Check if user has already purchased/downloaded this product
    const existingDownload = await db.download.findUnique({
      where: {
        userId_productId: {
          userId: session.user.id,
          productId,
        },
      },
    });

    // For free products, allow download
    if (product.isFree) {
      // Record download if not already recorded
      if (!existingDownload) {
        await db.download.create({
          data: {
            userId: session.user.id,
            productId,
          },
        });
        await db.product.update({
          where: { id: productId },
          data: { downloadCount: { increment: 1 } },
        });
      }

      return NextResponse.json({
        downloadUrl: product.fileUrl || `/downloads/${product.id}`,
        productName: product.name,
      });
    }

    // For paid products, check if user has purchased
    const order = await db.order.findFirst({
      where: {
        userId: session.user.id,
        productId,
        status: "completed",
      },
    });

    if (!order && !existingDownload) {
      return NextResponse.json(
        { error: "You need to purchase this product before downloading" },
        { status: 403 }
      );
    }

    // Record download if not already recorded
    if (!existingDownload) {
      await db.download.create({
        data: {
          userId: session.user.id,
          productId,
        },
      });
      await db.product.update({
        where: { id: productId },
        data: { downloadCount: { increment: 1 } },
      });
    }

    return NextResponse.json({
      downloadUrl: product.fileUrl || `/downloads/${product.id}`,
      productName: product.name,
    });
  } catch (error) {
    console.error("Download error:", error);
    return NextResponse.json(
      { error: "Failed to process download" },
      { status: 500 }
    );
  }
}
