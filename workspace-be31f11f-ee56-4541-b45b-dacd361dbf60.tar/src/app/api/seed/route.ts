import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Simple hash function for demo
function simpleHash(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(16);
}

export async function GET() {
  try {
    // Create or update admin user
    const adminPassword = simpleHash("admin123");
    await db.user.upsert({
      where: { email: "admin@store.com" },
      update: { password: adminPassword, name: "Admin User", role: "admin" },
      create: {
        email: "admin@store.com",
        password: adminPassword,
        name: "Admin User",
        role: "admin",
      },
    });

    // Create or update sample user
    const userPassword = simpleHash("user123");
    await db.user.upsert({
      where: { email: "user@example.com" },
      update: { password: userPassword, name: "John Doe", role: "user" },
      create: {
        email: "user@example.com",
        password: userPassword,
        name: "John Doe",
        role: "user",
      },
    });

    // Check if products already seeded
    const existingProducts = await db.product.count();
    if (existingProducts > 0) {
      return NextResponse.json({ 
        message: "Database already seeded",
        credentials: {
          admin: { email: "admin@store.com", password: "admin123" },
          user: { email: "user@example.com", password: "user123" }
        }
      });
    }

    // Create sample products
    const products = [
      {
        name: "Ultimate UI Kit Pro",
        description: "A comprehensive UI kit with 500+ components for modern web applications. Includes dark mode support, responsive design, and Figma files.",
        price: 49.99,
        imageUrl: "https://images.unsplash.com/photo-1559028012-481c04fa702d?w=800&q=80",
        fileUrl: "/downloads/ui-kit-pro.zip",
        category: "UI Design",
        isFree: false,
        isFeatured: true,
      },
      {
        name: "JavaScript Essentials E-Book",
        description: "Master JavaScript fundamentals with this comprehensive e-book. Perfect for beginners and intermediate developers.",
        price: 0,
        imageUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=800&q=80",
        fileUrl: "/downloads/js-essentials.pdf",
        category: "E-Books",
        isFree: true,
        isFeatured: true,
      },
      {
        name: "React Dashboard Template",
        description: "Professional admin dashboard template built with React, TypeScript, and Tailwind CSS. Includes charts, tables, and authentication.",
        price: 79.99,
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80",
        fileUrl: "/downloads/react-dashboard.zip",
        category: "Templates",
        isFree: false,
        isFeatured: true,
      },
      {
        name: "Icon Pack - 1000+ Icons",
        description: "Premium icon pack with 1000+ carefully crafted icons in SVG, PNG, and icon font formats. Perfect for any project.",
        price: 0,
        imageUrl: "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&q=80",
        fileUrl: "/downloads/icon-pack.zip",
        category: "Graphics",
        isFree: true,
        isFeatured: false,
      },
      {
        name: "Python Data Science Course",
        description: "Complete video course on Python for Data Science. 50+ hours of content covering pandas, numpy, matplotlib, and machine learning.",
        price: 199.99,
        imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80",
        fileUrl: "/downloads/python-ds-course.zip",
        category: "Courses",
        isFree: false,
        isFeatured: true,
      },
      {
        name: "CSS Animation Library",
        description: "Collection of 200+ CSS animations ready to use. Includes hover effects, loading animations, and page transitions.",
        price: 0,
        imageUrl: "https://images.unsplash.com/photo-1550063873-ab792950096b?w=800&q=80",
        fileUrl: "/downloads/css-animations.zip",
        category: "Code",
        isFree: true,
        isFeatured: false,
      },
      {
        name: "Landing Page Templates",
        description: "10 modern landing page templates for SaaS, apps, and products. Fully responsive and customizable.",
        price: 39.99,
        imageUrl: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&q=80",
        fileUrl: "/downloads/landing-pages.zip",
        category: "Templates",
        isFree: false,
        isFeatured: false,
      },
      {
        name: "Git & GitHub Mastery Guide",
        description: "Learn Git from basics to advanced. Includes branching strategies, collaboration workflows, and CI/CD integration.",
        price: 0,
        imageUrl: "https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=800&q=80",
        fileUrl: "/downloads/git-mastery.pdf",
        category: "E-Books",
        isFree: true,
        isFeatured: false,
      },
    ];

    for (const product of products) {
      await db.product.create({ data: product });
    }

    return NextResponse.json({ 
      message: "Database seeded successfully",
      products: products.length,
      credentials: {
        admin: { email: "admin@store.com", password: "admin123" },
        user: { email: "user@example.com", password: "user123" }
      }
    });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { error: "Failed to seed database" },
      { status: 500 }
    );
  }
}
