import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: "You must be logged in to place an order" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { productId, paymentMethod } = body;

    const product = await db.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // For WhatsApp payment, create pending order
    if (paymentMethod === "whatsapp") {
      const order = await db.order.create({
        data: {
          userId: session.user.id,
          productId,
          amount: product.price,
          currency: "USD",
          status: "pending",
          paymentMethod: "whatsapp",
        },
      });

      return NextResponse.json({
        success: true,
        order,
        whatsappLink: `https://wa.me/255123456789?text=${encodeURIComponent(
          `Hi, I want to purchase "${product.name}" for $${product.price}. Order ID: ${order.id}`
        )}`,
      });
    }

    // For demo purposes, mark as completed
    const order = await db.order.create({
      data: {
        userId: session.user.id,
        productId,
        amount: product.price,
        currency: "USD",
        status: "completed",
        paymentMethod: paymentMethod || "demo",
      },
    });

    return NextResponse.json({ success: true, order });
  } catch (error) {
    console.error("Order error:", error);
    return NextResponse.json(
      { error: "Failed to process order" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: "You must be logged in to view orders" },
        { status: 401 }
      );
    }

    const orders = await db.order.findMany({
      where: { userId: session.user.id },
      include: { product: true },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ orders });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return NextResponse.json(
      { error: "Failed to fetch orders" },
      { status: 500 }
    );
  }
}
