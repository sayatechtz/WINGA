import { NextResponse } from "next/server";

// Check if Google OAuth is configured
const isGoogleConfigured = 
  process.env.GOOGLE_CLIENT_ID && 
  process.env.GOOGLE_CLIENT_SECRET &&
  process.env.GOOGLE_CLIENT_ID.length > 10 &&
  process.env.GOOGLE_CLIENT_SECRET.length > 10;

export async function GET() {
  return NextResponse.json({
    googleAuthAvailable: isGoogleConfigured,
    clientId: isGoogleConfigured ? process.env.GOOGLE_CLIENT_ID?.substring(0, 10) + "..." : null,
  });
}
