"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Search,
  Menu,
  X,
  Download,
  Star,
  Crown,
  ArrowRight,
  MessageCircle,
  LogOut,
  Package,
  LayoutDashboard,
  Plus,
  Edit,
  Trash2,
  DollarSign,
  Users,
  Lock,
  ShoppingCart,
  Sparkles,
  Rocket,
  Code,
  Palette,
  BookOpen,
  Laptop,
  ChevronLeft,
  ChevronRight,
  FileText,
} from "lucide-react";
import { siteConfig } from "@/lib/config";
import { signInWithGoogle, signOut, getCurrentUser, onAuthStateChange } from "@/lib/supabase/auth";

// Types
interface UserType {
  id: string;
  email: string;
  name?: string;
  image?: string;
  role: string;
}

interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  imageUrl: string;
  fileUrl?: string;
  category?: string;
  isFree: boolean;
  isFeatured: boolean;
  downloadCount: number;
  createdAt: string;
}

// Currency rate for display
const CURRENCY_RATE = 2500; // USD to TSh

// Format price in TSh
const formatPriceTSh = (priceUSD: number): string => {
  const priceTSh = priceUSD * CURRENCY_RATE;
  return `TSh ${priceTSh.toLocaleString()}`;
};

// Sanitize input
const sanitizeInput = (input: string): string => {
  return input.replace(/[<>]/g, '').replace(/javascript:/gi, '').trim();
};

// Product Card Component
function ProductCard({ 
  product, 
  user, 
  onDownload, 
  onBuy, 
  onLogin 
}: { 
  product: Product; 
  user: UserType | null; 
  onDownload: (p: Product) => void; 
  onBuy: (p: Product) => void; 
  onLogin: () => void;
}) {
  return (
    <div className="flex-shrink-0 w-[160px] sm:w-[180px] bg-white rounded-lg border overflow-hidden hover:shadow-lg transition-shadow">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        {/* Badges */}
        <div className="absolute top-1 left-1 flex gap-1">
          {product.isFeatured && (
            <Badge className="bg-yellow-500 text-white text-[10px] px-1.5 py-0.5">
              <Star className="w-2.5 h-2.5 mr-0.5" />TOP
            </Badge>
          )}
          {product.isFree && (
            <Badge className="bg-green-500 text-white text-[10px] px-1.5 py-0.5">FREE</Badge>
          )}
        </div>
      </div>
      
      {/* Info & Buttons */}
      <div className="p-2">
        <h3 className="font-medium text-xs line-clamp-2 mb-1 min-h-[32px]">{product.name}</h3>
        
        {/* Price */}
        <p className="text-sm font-bold text-orange-600 mb-2">
          {product.isFree ? "FREE" : formatPriceTSh(product.price)}
        </p>
        
        {/* Buttons - Download & Buy together */}
        <div className="flex gap-1">
          <Button
            size="sm"
            className="flex-1 h-7 text-[10px] bg-green-600 hover:bg-green-700 text-white"
            onClick={() => user ? onDownload(product) : onLogin()}
          >
            <Download className="w-3 h-3 mr-0.5" />
            {product.isFree ? "Pakua" : "Download"}
          </Button>
          {!product.isFree && (
            <Button
              size="sm"
              className="flex-1 h-7 text-[10px] bg-orange-500 hover:bg-orange-600 text-white"
              onClick={() => user ? onBuy(product) : onLogin()}
            >
              <ShoppingCart className="w-3 h-3 mr-0.5" />
              Nunua
            </Button>
          )}
        </div>
        
        {/* Downloads count */}
        <div className="flex items-center justify-center gap-1 mt-1.5 text-[10px] text-gray-400">
          <Download className="w-2.5 h-2.5" />
          <span>{product.downloadCount} downloads</span>
        </div>
      </div>
    </div>
  );
}

// Category Section with Horizontal Scroll
function CategorySection({ 
  title, 
  products, 
  user, 
  onDownload, 
  onBuy, 
  onLogin 
}: { 
  title: string; 
  products: Product[]; 
  user: UserType | null; 
  onDownload: (p: Product) => void; 
  onBuy: (p: Product) => void; 
  onLogin: () => void;
}) {
  const scrollRef = useState<HTMLDivElement | null>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = useCallback((el: HTMLDivElement | null) => {
    if (el) {
      setCanScrollLeft(el.scrollLeft > 0);
      setCanScrollRight(el.scrollLeft < el.scrollWidth - el.clientWidth - 10);
    }
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    const el = scrollRef[0];
    if (el) {
      const scrollAmount = 340; // Approximately 2 product cards
      el.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const el = scrollRef[0];
    if (el) {
      // Initial check after a small delay to ensure element is rendered
      const timer = setTimeout(() => checkScroll(el), 100);
      const handleScroll = () => checkScroll(el);
      el.addEventListener('scroll', handleScroll);
      return () => {
        clearTimeout(timer);
        el.removeEventListener('scroll', handleScroll);
      };
    }
  }, [checkScroll, scrollRef, products]);

  if (products.length === 0) return null;

  return (
    <div className="mb-6">
      {/* Category Header */}
      <div className="flex items-center justify-between mb-3 px-2 sm:px-0">
        <h3 className="text-base sm:text-lg font-bold flex items-center gap-2">
          <Package className="w-4 h-4 text-orange-500" />
          {title}
          <Badge variant="secondary" className="text-xs">{products.length}</Badge>
        </h3>
        <div className="flex gap-1">
          <Button
            variant="outline"
            size="sm"
            className="h-7 w-7 p-0"
            onClick={() => scroll('left')}
            disabled={!canScrollLeft}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7 w-7 p-0"
            onClick={() => scroll('right')}
            disabled={!canScrollRight}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      {/* Horizontal Scroll Container */}
      <div 
        ref={(el) => { (scrollRef as any)[1]?.(el); }}
        className="flex gap-3 overflow-x-auto pb-2 px-2 sm:px-0 scrollbar-hide"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {/* Products - 2 per "page" */}
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            user={user}
            onDownload={onDownload}
            onBuy={onBuy}
            onLogin={onLogin}
          />
        ))}
      </div>
    </div>
  );
}

export default function DigitalStore() {
  const { toast } = useToast();
  
  // State
  const [user, setUser] = useState<UserType | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  
  // Auth
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [authForm, setAuthForm] = useState({ email: "", password: "", name: "" });
  const [authLoading, setAuthLoading] = useState(false);
  
  // Products
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceFilter, setPriceFilter] = useState<"all" | "free" | "paid">("all");
  const [sortBy, setSortBy] = useState("createdAt");
  
  // Admin
  const [adminProducts, setAdminProducts] = useState<Product[]>([]);
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState({
    name: "", description: "", price: "0", imageUrl: "", fileUrl: "", category: "", isFree: false, isFeatured: false,
  });
  const [deleteProductId, setDeleteProductId] = useState<string | null>(null);
  
  // Dialogs
  const [orderDialogOpen, setOrderDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [contactDialogOpen, setContactDialogOpen] = useState(false);
  const [contactForm, setContactForm] = useState({ name: "", email: "", subject: "", message: "" });

  // Initialize
  useEffect(() => {
    // Check Supabase auth
    const checkAuth = async () => {
      const supabaseUser = await getCurrentUser();
      if (supabaseUser) {
        const userData: UserType = {
          id: supabaseUser.id,
          email: supabaseUser.email || '',
          name: supabaseUser.user_metadata?.name || supabaseUser.email?.split('@')[0],
          image: supabaseUser.user_metadata?.avatar_url || supabaseUser.user_metadata?.picture,
          role: supabaseUser.user_metadata?.role || 'user',
        };
        setUser(userData);
        setIsAdmin(userData.role === "admin");
        if (userData.role === "admin") {
          setShowAdminDashboard(true);
        }
      }
      setLoading(false);
    };
    
    checkAuth();
    
    // Subscribe to auth changes
    const subscription = onAuthStateChange((authUser) => {
      if (authUser) {
        const userData: UserType = {
          id: authUser.id,
          email: authUser.email || '',
          name: authUser.user_metadata?.name || authUser.email?.split('@')[0],
          image: authUser.user_metadata?.avatar_url || authUser.user_metadata?.picture,
          role: authUser.user_metadata?.role || 'user',
        };
        setUser(userData);
        setIsAdmin(userData.role === "admin");
      } else {
        setUser(null);
        setIsAdmin(false);
        setShowAdminDashboard(false);
      }
    });
    
    return () => {
      subscription?.unsubscribe();
    };
  }, []);

  // Fetch products
  const fetchProducts = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", sanitizeInput(searchQuery));
      if (selectedCategory !== "all") params.append("category", selectedCategory);
      if (priceFilter !== "all") params.append("isFree", priceFilter === "free" ? "true" : "false");
      params.append("sortBy", sortBy);
      params.append("sortOrder", "desc");

      const res = await fetch(`/api/products?${params}`);
      const data = await res.json();
      setProducts(data.products || []);
      setCategories(data.categories || []);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    }
  }, [searchQuery, selectedCategory, priceFilter, sortBy]);

  useEffect(() => {
    fetchProducts();
    fetch("/api/seed").then(() => fetchProducts());
  }, [fetchProducts]);

  // Fetch admin data
  const fetchAdminData = async () => {
    try {
      const [productsRes, usersRes] = await Promise.all([
        fetch("/api/admin/products"),
        fetch("/api/admin/users"),
      ]);
      const productsData = await productsRes.json();
      const usersData = await usersRes.json();
      setAdminProducts(productsData.products || []);
      setAdminUsers(usersData.users || []);
    } catch (error) {
      console.error("Failed to fetch admin data:", error);
    }
  };

  useEffect(() => {
    if (isAdmin && showAdminDashboard) {
      fetchAdminData();
    }
  }, [isAdmin, showAdminDashboard]);

  // Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authForm.email.toLowerCase().trim(),
          password: authForm.password,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        localStorage.setItem('digitalmart_user', JSON.stringify(data.user));
        setUser(data.user);
        setIsAdmin(data.user.role === "admin");
        setAuthDialogOpen(false);
        setAuthForm({ email: "", password: "", name: "" });
        
        if (data.user.role === "admin") {
          setShowAdminDashboard(true);
        }
        
        toast({ title: "Karibu!", description: `Umeingia kama ${data.user.name}` });
      } else {
        toast({ title: "Error", description: data.error || "Login failed", variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Connection error", variant: "destructive" });
    } finally {
      setAuthLoading(false);
    }
  };

  // Google Sign In
  const handleGoogleSignIn = async () => {
    try {
      setAuthLoading(true);
      await signInWithGoogle();
      // The page will redirect to Google, then back to callback
    } catch (error: any) {
      toast({ title: "Error", description: error.message || "Google sign in failed", variant: "destructive" });
      setAuthLoading(false);
    }
  };

  // Register
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authForm.email.toLowerCase().trim(),
          password: authForm.password,
          name: authForm.name || authForm.email.split("@")[0],
        }),
      });

      const data = await res.json();

      if (res.ok) {
        const loginRes = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: authForm.email.toLowerCase().trim(),
            password: authForm.password,
          }),
        });
        const loginData = await loginRes.json();

        if (loginRes.ok && loginData.success) {
          localStorage.setItem('digitalmart_user', JSON.stringify(loginData.user));
          setUser(loginData.user);
        }
        setAuthDialogOpen(false);
        setAuthForm({ email: "", password: "", name: "" });
        toast({ title: "Success!", description: "Account created" });
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Connection error", variant: "destructive" });
    } finally {
      setAuthLoading(false);
    }
  };

  // Logout
  const handleLogout = async () => {
    try {
      await signOut();
    } catch {
      // fallback
    }
    setUser(null);
    setIsAdmin(false);
    setShowAdminDashboard(false);
    toast({ title: "Logged out", description: "Karibu tena!" });
  };

  // Download
  const handleDownload = async (product: Product) => {
    if (!user) {
      setAuthDialogOpen(true);
      return;
    }

    if (!product.isFree) {
      setSelectedProduct(product);
      setOrderDialogOpen(true);
      return;
    }

    try {
      await fetch(`/api/download/${product.id}`);
      
      const link = document.createElement("a");
      link.href = product.fileUrl || `/api/file/${product.id}`;
      link.download = `${product.name.replace(/[^a-zA-Z0-9]/g, '_')}.zip`;
      link.target = "_blank";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({ title: "Download Started!", description: product.name });
      fetchProducts();
    } catch {
      toast({ title: "Error", description: "Download failed", variant: "destructive" });
    }
  };

  // Buy
  const handleBuy = (product: Product) => {
    if (!user) {
      setAuthDialogOpen(true);
      return;
    }
    setSelectedProduct(product);
    setOrderDialogOpen(true);
  };

  // WhatsApp purchase
  const handleWhatsAppPurchase = (product: Product) => {
    const message = encodeURIComponent(
      `Jambo! Nataka kununua:\n\n📦 ${product.name}\n💰 ${formatPriceTSh(product.price)}\n\nTafadhali nipatie maelekezo ya malipo.`
    );
    window.open(`https://wa.me/${siteConfig.whatsapp.number}?text=${message}`, "_blank");
    
    fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, paymentMethod: "whatsapp" }),
    });
    
    setOrderDialogOpen(false);
    toast({ title: "WhatsApp Opened", description: "Malipo kwa WhatsApp" });
  };

  // Admin: Create product
  const handleCreateProduct = async () => {
    try {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: sanitizeInput(productForm.name),
          description: sanitizeInput(productForm.description || ""),
          price: parseFloat(productForm.price) || 0,
          imageUrl: productForm.imageUrl,
          fileUrl: productForm.fileUrl,
          category: productForm.category,
          isFree: productForm.isFree,
          isFeatured: productForm.isFeatured,
        }),
      });

      if (res.ok) {
        toast({ title: "Success", description: "Product created" });
        setProductForm({ name: "", description: "", price: "0", imageUrl: "", fileUrl: "", category: "", isFree: false, isFeatured: false });
        fetchAdminData();
        fetchProducts();
      }
    } catch {
      toast({ title: "Error", description: "Failed", variant: "destructive" });
    }
  };

  // Admin: Update product
  const handleUpdateProduct = async () => {
    if (!editingProduct) return;
    try {
      const res = await fetch("/api/admin/products", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: editingProduct.id,
          name: sanitizeInput(productForm.name),
          description: sanitizeInput(productForm.description || ""),
          price: parseFloat(productForm.price) || 0,
          imageUrl: productForm.imageUrl,
          fileUrl: productForm.fileUrl,
          category: productForm.category,
          isFree: productForm.isFree,
          isFeatured: productForm.isFeatured,
        }),
      });

      if (res.ok) {
        toast({ title: "Updated", description: "Product updated" });
        setEditingProduct(null);
        setProductForm({ name: "", description: "", price: "0", imageUrl: "", fileUrl: "", category: "", isFree: false, isFeatured: false });
        fetchAdminData();
        fetchProducts();
      }
    } catch {
      toast({ title: "Error", description: "Failed", variant: "destructive" });
    }
  };

  // Admin: Delete product
  const handleDeleteProduct = async () => {
    if (!deleteProductId) return;
    try {
      const res = await fetch(`/api/admin/products?id=${deleteProductId}`, { method: "DELETE" });
      if (res.ok) {
        toast({ title: "Deleted", description: "Product removed" });
        setDeleteProductId(null);
        fetchAdminData();
        fetchProducts();
      }
    } catch {
      toast({ title: "Error", description: "Failed", variant: "destructive" });
    }
  };

  // Edit product
  const openEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      description: product.description || "",
      price: product.price.toString(),
      imageUrl: product.imageUrl,
      fileUrl: product.fileUrl || "",
      category: product.category || "",
      isFree: product.isFree,
      isFeatured: product.isFeatured,
    });
  };

  // Contact
  const handleContact = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: sanitizeInput(contactForm.name),
          email: sanitizeInput(contactForm.email),
          subject: sanitizeInput(contactForm.subject || ""),
          message: sanitizeInput(contactForm.message),
        }),
      });

      if (res.ok) {
        toast({ title: "Sent!", description: "Message sent" });
        setContactDialogOpen(false);
        setContactForm({ name: "", email: "", subject: "", message: "" });
      }
    } catch {
      toast({ title: "Error", description: "Failed", variant: "destructive" });
    }
  };

  // Group products by category
  const productsByCategory = categories.reduce((acc, category) => {
    const categoryProducts = products.filter(p => p.category === category);
    if (categoryProducts.length > 0) {
      acc[category] = categoryProducts;
    }
    return acc;
  }, {} as Record<string, Product[]>);

  // Products without category
  const uncategorizedProducts = products.filter(p => !p.category);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <img src="/logo.png" alt="Sayatechtz" className="w-12 h-12 mx-auto animate-pulse rounded-lg object-cover" />
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Admin Dashboard View
  if (isAdmin && showAdminDashboard) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Sayatechtz" className="w-10 h-10 rounded-lg object-cover" />
              <span className="text-xl font-bold">Admin Dashboard</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setShowAdminDashboard(false)}>
                View Store
              </Button>
              <Button variant="ghost" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-1" /> Logout
              </Button>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-6">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg border">
              <div className="flex items-center gap-2 text-orange-600 mb-2">
                <Package className="w-5 h-5" /><span className="text-sm">Products</span>
              </div>
              <p className="text-2xl font-bold">{adminProducts.length}</p>
            </div>
            <div className="bg-white p-4 rounded-lg border">
              <div className="flex items-center gap-2 text-blue-600 mb-2">
                <Users className="w-5 h-5" /><span className="text-sm">Users</span>
              </div>
              <p className="text-2xl font-bold">{adminUsers.length}</p>
            </div>
            <div className="bg-white p-4 rounded-lg border">
              <div className="flex items-center gap-2 text-green-600 mb-2">
                <Download className="w-5 h-5" /><span className="text-sm">Downloads</span>
              </div>
              <p className="text-2xl font-bold">{adminProducts.reduce((a, p) => a + p.downloadCount, 0)}</p>
            </div>
            <div className="bg-white p-4 rounded-lg border">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <DollarSign className="w-5 h-5" /><span className="text-sm">Revenue</span>
              </div>
              <p className="text-2xl font-bold">TSh {adminProducts.filter(p => !p.isFree).reduce((a, p) => a + p.price * p.downloadCount * 2500, 0).toLocaleString()}</p>
            </div>
          </div>

          {/* Product Form */}
          <div className="bg-white p-4 rounded-lg border mb-6">
            <h3 className="font-semibold mb-4">{editingProduct ? "Edit Product" : "Add Product"}</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <Label className="text-xs">Name</Label>
                <Input value={productForm.name} onChange={(e) => setProductForm({ ...productForm, name: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">Price ($)</Label>
                <Input type="number" value={productForm.price} onChange={(e) => setProductForm({ ...productForm, price: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">Category</Label>
                <Select value={productForm.category} onValueChange={(v) => setProductForm({ ...productForm, category: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UI Design">UI Design</SelectItem>
                    <SelectItem value="Templates">Templates</SelectItem>
                    <SelectItem value="E-Books">E-Books</SelectItem>
                    <SelectItem value="Courses">Courses</SelectItem>
                    <SelectItem value="Graphics">Graphics</SelectItem>
                    <SelectItem value="Code">Code</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Image URL</Label>
                <Input value={productForm.imageUrl} onChange={(e) => setProductForm({ ...productForm, imageUrl: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <Label className="text-xs">Description</Label>
                <Input value={productForm.description} onChange={(e) => setProductForm({ ...productForm, description: e.target.value })} />
              </div>
              <div>
                <Label className="text-xs">File URL</Label>
                <Input value={productForm.fileUrl} onChange={(e) => setProductForm({ ...productForm, fileUrl: e.target.value })} />
              </div>
              <div className="flex items-end gap-4">
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={productForm.isFree} onCheckedChange={(v) => setProductForm({ ...productForm, isFree: v })} />
                  Free
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <Switch checked={productForm.isFeatured} onCheckedChange={(v) => setProductForm({ ...productForm, isFeatured: v })} />
                  Featured
                </label>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={editingProduct ? handleUpdateProduct : handleCreateProduct} className="bg-gradient-to-r from-orange-500 to-red-600 text-white">
                <Plus className="w-4 h-4 mr-1" />{editingProduct ? "Update" : "Add"}
              </Button>
              {editingProduct && (
                <Button variant="outline" onClick={() => {
                  setEditingProduct(null);
                  setProductForm({ name: "", description: "", price: "0", imageUrl: "", fileUrl: "", category: "", isFree: false, isFeatured: false });
                }}>Cancel</Button>
              )}
            </div>
          </div>

          {/* Products Table */}
          <div className="bg-white rounded-lg border overflow-hidden">
            <ScrollArea className="h-[400px]">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 sticky top-0">
                  <tr>
                    <th className="text-left p-3">Product</th>
                    <th className="text-left p-3 hidden sm:table-cell">Category</th>
                    <th className="text-left p-3">Price</th>
                    <th className="text-left p-3 hidden md:table-cell">Downloads</th>
                    <th className="text-right p-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {adminProducts.map((product) => (
                    <tr key={product.id} className="border-t hover:bg-gray-50">
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <img src={product.imageUrl} alt={product.name} className="w-10 h-10 rounded object-cover" />
                          <div>
                            <p className="font-medium line-clamp-1">{product.name}</p>
                            <div className="flex gap-1">
                              {product.isFree && <Badge className="bg-green-500 text-xs">Free</Badge>}
                              {product.isFeatured && <Badge className="bg-yellow-500 text-xs">Featured</Badge>}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 hidden sm:table-cell text-gray-600">{product.category}</td>
                      <td className="p-3 font-medium">{product.isFree ? "Free" : formatPriceTSh(product.price)}</td>
                      <td className="p-3 hidden md:table-cell text-gray-600">{product.downloadCount}</td>
                      <td className="p-3 text-right">
                        <Button size="sm" variant="ghost" onClick={() => openEditProduct(product)}><Edit className="w-4 h-4" /></Button>
                        <Button size="sm" variant="ghost" className="text-red-600" onClick={() => setDeleteProductId(product.id)}><Trash2 className="w-4 h-4" /></Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </ScrollArea>
          </div>
        </main>

        <AlertDialog open={!!deleteProductId} onOpenChange={() => setDeleteProductId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Product?</AlertDialogTitle>
              <AlertDialogDescription>This cannot be undone.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteProduct} className="bg-red-600">Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        <Toaster />
      </div>
    );
  }

  // Main Store View
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-2 sm:px-4">
          <div className="flex items-center justify-between h-14 sm:h-16">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Sayatechtz" className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg object-cover" />
              <span className="text-lg sm:text-xl font-bold">Sayatechtz</span>
            </div>

            {/* Search - Desktop */}
            <div className="hidden md:flex flex-1 max-w-xl mx-4 lg:mx-8">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-10 bg-gray-100 border-gray-200"
                />
              </div>
            </div>

            {/* Right */}
            <div className="flex items-center gap-2">
              <div className="hidden lg:flex items-center gap-2">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-32 h-9 bg-gray-100 border-0 text-sm"><SelectValue placeholder="Category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    {categories.map((cat) => (<SelectItem key={cat} value={cat}>{cat}</SelectItem>))}
                  </SelectContent>
                </Select>
                <Select value={priceFilter} onValueChange={(v) => setPriceFilter(v as any)}>
                  <SelectTrigger className="w-20 h-9 bg-gray-100 border-0 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="free">Free</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {user ? (
                <div className="flex items-center gap-2">
                  {isAdmin && (
                    <Button variant="ghost" size="sm" className="hidden sm:flex" onClick={() => setShowAdminDashboard(true)}>
                      <LayoutDashboard className="w-4 h-4 mr-1" />Admin
                    </Button>
                  )}
                  <Button variant="ghost" className="w-9 h-9 rounded-full p-0" onClick={handleLogout}>
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white text-sm font-medium">
                      {user.name?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase()}
                    </div>
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => { setAuthTab("login"); setAuthDialogOpen(true); }}>Sign In</Button>
                  <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-600 text-white" onClick={() => { setAuthTab("register"); setAuthDialogOpen(true); }}>Join Free</Button>
                </div>
              )}

              <Button variant="ghost" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-white p-3 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
            </div>
            <div className="flex gap-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="flex-1"><SelectValue placeholder="Category" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  {categories.map((cat) => (<SelectItem key={cat} value={cat}>{cat}</SelectItem>))}
                </SelectContent>
              </Select>
              <Select value={priceFilter} onValueChange={(v) => setPriceFilter(v as any)}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
      </header>

      {/* Main */}
      <main className="flex-1">
        {/* Hero Section - Compact */}
        <section className="relative overflow-hidden bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 text-white py-10 sm:py-14">
          {/* Animated Background */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-10 left-10 animate-bounce opacity-20">
              <Code className="w-12 h-12" />
            </div>
            <div className="absolute top-20 right-20 animate-bounce opacity-20" style={{ animationDelay: '300ms' }}>
              <Palette className="w-14 h-14" />
            </div>
            <div className="absolute bottom-20 left-20 animate-bounce opacity-20" style={{ animationDelay: '500ms' }}>
              <BookOpen className="w-10 h-10" />
            </div>
            <div className="absolute bottom-10 right-10 animate-bounce opacity-20" style={{ animationDelay: '700ms' }}>
              <Laptop className="w-12 h-12" />
            </div>
            <div className="absolute top-1/2 left-1/4 animate-pulse opacity-10">
              <Rocket className="w-18 h-18" />
            </div>
            <div className="absolute top-1/3 right-1/4 animate-pulse opacity-10" style={{ animationDelay: '200ms' }}>
              <Sparkles className="w-14 h-14" />
            </div>
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-yellow-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-pink-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" style={{ animationDelay: '1000ms' }}></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4">
            <div className="text-center">
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-4">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Best Digital Products in Tanzania</span>
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-3">
                Digital Products <span className="text-yellow-300">Marketplace</span>
              </h1>
              <p className="text-base sm:text-lg opacity-90 mb-5 max-w-xl mx-auto">
                Pakua free & paid digital products. UI Kits, Templates, E-Books, Courses, Graphics & more.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100 font-semibold px-6 h-10" onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}>
                  Browse Products <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 font-semibold px-6 h-10" onClick={() => setContactDialogOpen(true)}>
                  <MessageCircle className="mr-2 w-4 h-4" />Contact Us
                </Button>
              </div>
              
              {/* Stats */}
              <div className="flex justify-center gap-8 mt-8">
                <div className="text-center">
                  <p className="text-2xl font-bold">{products.length}</p>
                  <p className="text-xs opacity-80">Products</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold">{products.filter(p => p.isFree).length}</p>
                  <p className="text-xs opacity-80">Free Items</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold">{products.reduce((a, p) => a + p.downloadCount, 0)}</p>
                  <p className="text-xs opacity-80">Downloads</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Wave Divider */}
          <div className="absolute bottom-0 left-0 right-0">
            <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 60L60 50C120 40 240 20 360 15C480 10 600 20 720 25C840 30 960 30 1080 25C1200 20 1320 10 1380 5L1440 0V60H0Z" fill="#f9fafb"/>
            </svg>
          </div>
        </section>

        {/* Products Section - By Category with Horizontal Scroll */}
        <section id="products" className="py-6">
          <div className="max-w-7xl mx-auto">
            {/* Section Header */}
            <div className="flex items-center justify-between mb-4 px-2 sm:px-4">
              <h2 className="text-lg sm:text-xl font-bold">Products by Category</h2>
              <Badge variant="secondary" className="text-sm">{products.length} products</Badge>
            </div>

            {/* No Products */}
            {products.length === 0 && (
              <div className="text-center py-12 text-gray-500 px-4">
                <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No products found</p>
              </div>
            )}

            {/* Categories */}
            <div className="px-2 sm:px-4">
              {Object.entries(productsByCategory).map(([category, categoryProducts]) => (
                <CategorySection
                  key={category}
                  title={category}
                  products={categoryProducts}
                  user={user}
                  onDownload={handleDownload}
                  onBuy={handleBuy}
                  onLogin={() => setAuthDialogOpen(true)}
                />
              ))}
              
              {/* Uncategorized Products */}
              {uncategorizedProducts.length > 0 && (
                <CategorySection
                  title="Other"
                  products={uncategorizedProducts}
                  user={user}
                  onDownload={handleDownload}
                  onBuy={handleBuy}
                  onLogin={() => setAuthDialogOpen(true)}
                />
              )}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-6 bg-white border-t">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="text-center p-3">
                <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-orange-100 flex items-center justify-center">
                  <Download className="w-4 h-4 text-orange-600" />
                </div>
                <h3 className="font-medium text-sm">Instant Download</h3>
                <p className="text-xs text-gray-500">Pakua mara moja</p>
              </div>
              <div className="text-center p-3">
                <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-green-100 flex items-center justify-center">
                  <Lock className="w-4 h-4 text-green-600" />
                </div>
                <h3 className="font-medium text-sm">Secure Payment</h3>
                <p className="text-xs text-gray-500">Malipo salama</p>
              </div>
              <div className="text-center p-3">
                <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 text-blue-600" />
                </div>
                <h3 className="font-medium text-sm">WhatsApp Support</h3>
                <p className="text-xs text-gray-500">Msaada 24/7</p>
              </div>
              <div className="text-center p-3">
                <div className="w-9 h-9 mx-auto mb-2 rounded-full bg-purple-100 flex items-center justify-center">
                  <FileText className="w-4 h-4 text-purple-600" />
                </div>
                <h3 className="font-medium text-sm">Quality Products</h3>
                <p className="text-xs text-gray-500">Bidhaa bora</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="Sayatechtz" className="w-8 h-8 rounded-lg object-cover" />
              <span className="font-bold">Sayatechtz</span>
            </div>
            <div className="flex gap-4 text-sm text-gray-400">
              <button onClick={() => setContactDialogOpen(true)} className="hover:text-white">Contact</button>
              <a href={`https://wa.me/${siteConfig.whatsapp.number}`} target="_blank" rel="noopener" className="hover:text-white">WhatsApp</a>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-4 pt-4 text-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} {siteConfig.name}. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Auth Dialog */}
      <Dialog open={authDialogOpen} onOpenChange={setAuthDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogTitle className="sr-only">Authentication</DialogTitle>
          <Tabs value={authTab} onValueChange={(v) => setAuthTab(v as any)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            <TabsContent value="login" className="p-4">
              {/* Google Sign In */}
              <Button
                type="button"
                variant="outline"
                className="w-full mb-4 flex items-center justify-center gap-2"
                onClick={handleGoogleSignIn}
                disabled={authLoading}
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                {authLoading ? "Signing in..." : "Continue with Google"}
              </Button>
              
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">or</span>
                </div>
              </div>
              
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label>Email</Label>
                  <Input type="email" value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} required />
                </div>
                <div>
                  <Label>Password</Label>
                  <Input type="password" value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} required />
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white" disabled={authLoading}>
                  {authLoading ? "Signing in..." : "Sign In"}
                </Button>
              </form>
            </TabsContent>
            <TabsContent value="register" className="p-4">
              {/* Google Sign In */}
              <Button
                type="button"
                variant="outline"
                className="w-full mb-4 flex items-center justify-center gap-2"
                onClick={handleGoogleSignIn}
                disabled={authLoading}
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                {authLoading ? "Signing in..." : "Continue with Google"}
              </Button>
              
              <div className="relative mb-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">or</span>
                </div>
              </div>
              
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input value={authForm.name} onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })} />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input type="email" value={authForm.email} onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })} required />
                </div>
                <div>
                  <Label>Password</Label>
                  <Input type="password" value={authForm.password} onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })} required />
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white" disabled={authLoading}>
                  {authLoading ? "Creating account..." : "Create Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Order/Purchase Dialog */}
      <Dialog open={orderDialogOpen} onOpenChange={setOrderDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Buy Product</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <div className="space-y-4">
              <div className="flex gap-4">
                <img src={selectedProduct.imageUrl} alt={selectedProduct.name} className="w-20 h-20 rounded-lg object-cover" />
                <div>
                  <h3 className="font-semibold">{selectedProduct.name}</h3>
                  <p className="text-lg font-bold text-orange-600">{formatPriceTSh(selectedProduct.price)}</p>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Payment via WhatsApp</h4>
                <p className="text-sm text-gray-600 mb-3">
                  Click the button below to contact us on WhatsApp for payment instructions.
                </p>
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => handleWhatsAppPurchase(selectedProduct)}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Pay via WhatsApp
                </Button>
              </div>
              
              {selectedProduct.isFree && user && (
                <Button 
                  className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white"
                  onClick={() => {
                    handleDownload(selectedProduct);
                    setOrderDialogOpen(false);
                  }}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Free
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Contact Dialog */}
      <Dialog open={contactDialogOpen} onOpenChange={setContactDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contact Us</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleContact} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Name</Label>
                <Input value={contactForm.name} onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })} required />
              </div>
              <div>
                <Label>Email</Label>
                <Input type="email" value={contactForm.email} onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })} required />
              </div>
            </div>
            <div>
              <Label>Subject</Label>
              <Input value={contactForm.subject} onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })} />
            </div>
            <div>
              <Label>Message</Label>
              <textarea 
                className="w-full border rounded-md p-2 text-sm" 
                value={contactForm.message} 
                onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })} 
                required 
                rows={4} 
              />
            </div>
            <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white">
              Send Message
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Toaster />
    </div>
  );
}
