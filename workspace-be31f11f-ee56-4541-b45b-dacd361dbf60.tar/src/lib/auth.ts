import type { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { db } from "./db";

// Check if Google OAuth is configured
const googleClientId = process.env.GOOGLE_CLIENT_ID;
const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
const isGoogleConfigured = googleClientId && googleClientSecret && 
  googleClientId !== "your-google-client-id" && 
  googleClientSecret !== "your-google-client-secret";

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET || "digitalmart-secure-secret-2024",
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  pages: {
    signIn: "/",
    error: "/",
  },
  providers: [
    ...(isGoogleConfigured ? [
      GoogleProvider({
        clientId: googleClientId!,
        clientSecret: googleClientSecret!,
        authorization: {
          params: {
            prompt: "consent",
            access_type: "offline",
            scope: "openid email profile"
          }
        }
      })
    ] : []),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) {
        token.id = user.id;
        token.email = user.email;
        token.name = user.name;
        token.picture = user.image;
        
        // Get user from database to get role
        const dbUser = await db.user.findUnique({
          where: { email: user.email! }
        });
        
        if (dbUser) {
          token.id = dbUser.id;
          token.role = dbUser.role;
        } else {
          token.role = "user";
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.email = token.email as string;
        session.user.name = token.name as string;
        session.user.image = token.picture as string;
        (session.user as any).role = token.role as string;
      }
      return session;
    },
    async signIn({ user, account, profile }) {
      if (account?.provider === "google") {
        try {
          // Check if user exists
          const existingUser = await db.user.findUnique({
            where: { email: user.email! }
          });

          if (!existingUser) {
            // Create new user
            const newUser = await db.user.create({
              data: {
                email: user.email!,
                name: user.name || user.email!.split("@")[0],
                image: user.image,
                role: "user",
              },
            });
            (user as any).id = newUser.id;
            (user as any).role = newUser.role;
          } else {
            // Update existing user info
            await db.user.update({
              where: { email: user.email! },
              data: {
                name: user.name,
                image: user.image,
              },
            });
            (user as any).id = existingUser.id;
            (user as any).role = existingUser.role;
          }
          return true;
        } catch (error) {
          console.error("Google sign in error:", error);
          return false;
        }
      }
      return true;
    },
  },
  debug: process.env.NODE_ENV === "development",
};

// Export function to check if Google is configured
export function isGoogleAuthConfigured(): boolean {
  return isGoogleConfigured;
}

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      email: string;
      name?: string | null;
      image?: string | null;
      role: string;
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    email: string;
    name: string;
    picture: string;
    role: string;
  }
}
