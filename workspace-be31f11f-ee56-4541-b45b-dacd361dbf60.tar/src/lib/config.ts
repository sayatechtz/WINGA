// ===========================================
// SAYATECHTZ - WEBSITE SETTINGS
// ===========================================
// Badilisha haya majibu kulingana na mahitaji yako
// Change these settings according to your needs
// ===========================================

export const siteConfig = {
  // ========================================
  // JINA LA WEBSITE / WEBSITE NAME
  // ========================================
  name: "Sayatechtz",
  tagline: "Your Trusted Digital Products Partner",
  description: "Best digital products marketplace in Tanzania. UI Kits, Templates, E-Books, Courses & more.",
  
  // ========================================
  // CURRENCY SETTINGS / MIPANGILIO YA SARAFU
  // ========================================
  currency: {
    code: "TSh",
    symbol: "TSh",
    name: "Tanzanian Shilling",
    rate: 2500, // Exchange rate from USD to TSh (badilisha kama inahitajika)
  },
  
  // ========================================
  // WHATSAPP NUMBER / NAMBA YA WHATSAPP
  // ========================================
  // Badilisha na namba yako ya WhatsApp
  // Replace with your WhatsApp number (format: country code + number without +)
  whatsapp: {
    number: "255123456789", // Mfano: 255712345678
    message: "Jambo! Nina swali kuhusu Sayatechtz.",
  },
  
  // ========================================
  // HERO SECTION / SEKSHENI YA MWANZO
  // ========================================
  hero: {
    title: "Digital Products",
    highlight: "Marketplace",
    subtitle: "Pakua free & paid digital products. UI Kits, Templates, E-Books, Courses, Graphics & more at affordable prices.",
    badge: "Best Digital Products in Tanzania",
    showAnimation: true,
  },
  
  // ========================================
  // CONTACT INFO / TAARIFA ZA MAWASILIANO
  // ========================================
  contact: {
    email: "info@sayatechtz.com",
    phone: "+255 123 456 789",
    address: "Dar es Salaam, Tanzania",
  },
  
  // ========================================
  // SOCIAL MEDIA LINKS
  // ========================================
  social: {
    instagram: "https://instagram.com/sayatechtz",
    twitter: "https://twitter.com/sayatechtz",
    facebook: "https://facebook.com/sayatechtz",
  },
  
  // ========================================
  // DEMO CREDENTIALS
  // ========================================
  demo: {
    admin: { email: "admin@store.com", password: "admin123" },
    user: { email: "user@example.com", password: "user123" },
  },
  
  // ========================================
  // STORAGE KEY (don't change unless needed)
  // ========================================
  storageKey: "sayatechtz_user",
};

// Helper function kwa ajili ya kubadilisha bei kutoka USD
export function formatPrice(priceUSD: number): string {
  const priceTSh = priceUSD * siteConfig.currency.rate;
  return `${siteConfig.currency.symbol} ${priceTSh.toLocaleString()}`;
}

// Helper function kwa ajili ya WhatsApp link
export function getWhatsAppLink(message?: string): string {
  const msg = message || siteConfig.whatsapp.message;
  return `https://wa.me/${siteConfig.whatsapp.number}?text=${encodeURIComponent(msg)}`;
}

// Helper to get storage key
export function getStorageKey(): string {
  return siteConfig.storageKey;
}
